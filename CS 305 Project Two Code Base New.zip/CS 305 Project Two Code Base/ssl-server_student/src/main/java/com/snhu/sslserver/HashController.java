package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/hash")
public class HashController {

    @GetMapping
    public Map<String, String> getHashStatus() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "ok");
        response.put("algorithm", "SHA-256");
        return response;
    }

    @GetMapping("/sha256")
    public Map<String, String> getSha256Hash(@RequestParam("input") String input) throws Exception {
        java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));

        // Convert to hex string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        Map<String, String> response = new HashMap<>();
        response.put("input", input);
        response.put("algorithm", "SHA-256");
        response.put("checksum", hexString.toString());
        return response;
    }
}